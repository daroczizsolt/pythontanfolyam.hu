"""
szo1 = input("1. megadott szó:")
szo2 = input("2. megadott szó:")

azonosBetuk = []

for i in szo1:
    if i in szo2 and i not in azonosBetuk:
        azonosBetuk.append(i)
    
kiirat = ",".join(azonosBetuk) 


if len(azonosBetuk) == 0:
    print("A két szóban nincs közös betű!")
elif szo1 == szo2:
    print("A két szó teljesen azonos!")  
else:
    print("A közös betűk",kiirat)
      

def kiadasRogzites():
    tetel = 1
    kiadasok = []
    while True:
        kiadas = int(input(f"Kérem a(z) {tetel}. kiadási tételt (Ft):"))
        tetel +=1 
        if kiadas > 0:
            kiadasok.append(kiadas)
        elif kiadas < 0:
            print("Érvénytelen bevitel!")
        if kiadas == 0:
            break
    return kiadasok    

k = kiadasRogzites() 

def kiadasElemzes(ki, fizu):
    print("Kiadások darabszáma:", len(ki), "db.")
    print("Kiadások összege:", sum(ki))
    if sum(ki) <= fizu:
        print("Ön fedezni tudja a kiadásait a fizetéséből.")
        print("Megtakarított összeg:",fizu - sum(ki))
    else:
        print("Ön nem tudta fedezni a kiadásait a fizetéséből.")
            
f = int(input("Kérem adja meg a havi fizetését (Ft):"))

kiadasElemzes(k, f)           
    """
class Kiadas:
    def __init__(self, kategoria, datum, osszeg):
        self.kategoria = kategoria
        self.datum = datum
        self.osszeg = osszeg
        self.kedvezmeny = 0
        self.k_osszeg = osszeg

    def kedvezmenySzamitas(self, kedv): # 5
        self.kedvezmeny = kedv  
        self.k_osszeg -=  self.osszeg * (kedv/100)

import random        
kiadasok = []
f = open("kiadások.txt", "r", encoding="utf-8")
for i in f:
    adat = i.strip().split(";") # adat = ['otthon','2025-05-01', '11582']
    k = Kiadas(adat[0], adat[1], int(adat[2])) 
    if k.kategoria == "élelmiszer":
        kedv_merteke = random.randint(1,5)
        k.kedvezmenySzamitas(kedv_merteke) # 5
    kiadasok.append(k)
f.close()

fki = open("kiadasAdatok.txt", "w", encoding="utf-8")
for i in kiadasok:
    print("Kategória:", i.kategoria, file=fki)
    print("Dátum:", i.datum, file=fki)
    print("Összeg:", i.osszeg, file=fki)
    print("Kedvezmeny:", i.kedvezmeny, file=fki)
    print("Végső összeg:", i.k_osszeg, file=fki)
    print(40*"*", file=fki)

fki.close()    