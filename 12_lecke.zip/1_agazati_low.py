"""
print("1. feladat: BMI kalkulátor!")

suly = float(input("Kérem testsúlyát(kg)"))
magassag = float(input("Kérem magasságát(cm)"))

magassag = magassag / 100
bmi = suly / (magassag**2)
print("Az Ön BMI értéke:", round(bmi,2))

if bmi < 18.5:
    print("Sovány")
elif bmi >= 18.5 and  bmi <=24.9:
    print("Normál testsúly")
else:
    print("Túlsúlyos az illető")  


def FizzBuzz(szam):
    if szam % 3 == 0 and szam % 5 == 0:
        return "FizzBuzz"
    elif szam % 3 == 0:
        return "Fizz"
    elif szam % 5 == 0:
        return "Buzz"
    else:
        return str(szam)
    
import random    
for i in range(100):
    vszam = random.randint(1,100)
    print(vszam ,"->",FizzBuzz(vszam))

"""

class Termek:
    def __init__(self, nev, ar, mennyiseg):
        self.nev = nev
        self.ar = ar
        self.mennyiseg = mennyiseg

    def arFrissites(self, ertek): # -5
        self.ar += self.ar * (ertek/100)    
   
            

termekek = []        
f = open("termekek.txt", "r", encoding="utf8")
for i in f: #i = "Alma;480;120\n"
    adat = i.strip().split(";") # adat = ["Alma", "480", "120"]
    t = Termek(adat[0], int(adat[1]), int(adat[2])) 
    termekek.append(t)
f.close() 


legdragabb = 0
legdragabbNeve = ""
for i in termekek:
    if i.ar > legdragabb:
        legdragabb = i.ar
        legdragabbNeve = i.nev
print(f"A legnagyobb egységárú termék a(z) {legdragabbNeve}")        

for i in termekek:
    if i.mennyiseg < 50:
        i.arFrissites(10)
    elif i.mennyiseg > 150:
        i.arFrissites(-5)

fki = open("termekekFrissitve.txt", "w", encoding="utf-8")
for i in termekek:
    print(f"{i.nev}: {i.ar} Ft/kg, készlet: {i.mennyiseg} kg ", file=fki)
fki.close()    
    

