"""
print("1. feladat Kalóriadeficit")

multhetiK = int(input("Kérem adja meg a múltheti kalóriabevitelének összegét:"))

sz = 1
jelenlegiH = 0
for i in range(7):
    nap = int(input(f"{sz}. nap kalóriabevitele:")) 
    sz += 1
    jelenlegiH += nap

if multhetiK < jelenlegiH:
    print("Több kalóriát vitt be, mint múlthéten.")  
elif multhetiK > jelenlegiH:
    print("Kevesebb kalóriát vitt be, mint múlthéten.") 
else:
    print("Ugyanannyi kalóriát vitt be, mint múlthéten.")
   

def KerekEvszamok(tol, ig):
    lst = []
    for i in range(tol, ig + 1):
        if i % 10 == 0:
            lst.append(i)
    return lst  

betol = int(input("Kérem az alsó határéték évszámát! "))
beig = int(input("Kérem a felső határéték évszámát! "))
kerekSzamok = KerekEvszamok(betol, beig)

if len(kerekSzamok) > 0:
   #  for i in kerekSzamok:
   #      print(i, end=",")
   atalakit = ",".join(map(str, kerekSzamok))
   print(atalakit)
else:
    print("A két érték között nincsenek kerek számok!")   
    

 """

class Sportolo:
    def __init__(self, nev, sportag, eremSzam):
        self.nev = nev
        self.sportag = sportag
        self.eremSzam = eremSzam

    def ElismertsegSzint(self):
        if self.eremSzam > 5:
            return "világhírű"
        elif self.eremSzam <= 5 and self.eremSzam >= 2:
            return "kontinentális"
        else:
            return "nemzetközi"

sportolokLst = []
for i in range(3):
    nev = input("Adja meg a sportoló nevét!")
    sportag = input("Adja meg a sportágát!")
    eremszam = int(input("Adja meg az aranyérmeinek a számát!"))
    s = Sportolo(nev, sportag, eremszam)
    sportolokLst.append(s)

for i in sportolokLst:
    print(f"{i.nev} egy {i.sportag} {i.ElismertsegSzint()} versenyző {i.eremSzam} db aranyéremmel ")

legtobb = 0
legtobbNev = ""
for i in sportolokLst:
    if i.eremSzam >legtobb:
        legtobb = i.eremSzam # 7
        legtobbNev = i.nev

fki = open("leghiresebb.txt", "w", encoding="utf-8")
print(f"{legtobbNev} versenyzőnek van a legtöbb aranyérme.", file=fki)
fki.close()
            

        
    

             
            
    