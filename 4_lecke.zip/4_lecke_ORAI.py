#IV. lecke ELÁGAZÁSOK, RANDOM SZÁMOK

#ppt minta

szam = int(input("Kérem a számot:"))

if szam < 20:
   print("A szám kisebb, mint 20.")
elif szam == 20:
   print("A két szám egyenlő.")   
else:
   print("A szám nagyobb 20.")   

# % jel aritmetikai operátor

print(5%2)
print(5//2)  
print(5/2) 

# vizsgálat hogy 10 és 30 között van, beleértve a határértékeket 
szam = 30
if  10 <= szam <= 30:
   print("A szám 10 és 30 között van")
else:
   print("A szám nincs 10 és 30 között van")


#1 Készíts egy programot, amely megkérdezi a felhasználótól, hogy jó napja van-e!
# A válasz kétféle lehet: igen vagy nem. A választól függően írjon ki üzenetet a gép!

napom = input("Jó napod van? (igen/nem)")
if napom == "igen":
   print("Ennek nagyon örülök!")
else:
   print("Sajnálom, majd holnap hátha jobb lesz.")   

    
#1.1 Fejleszd tovább az első feladat programját úgy, hogy amennyiben a felhasználó nem a két lehetséges válasz
# (igen/nem) közül ad meg egyet, a gép kiírja: "Sajnos nem értem a válaszodat!"

napom = input("Jó napod van? (igen/nem)")
if napom == "igen":
   print("Ennek nagyon örülök!")
elif napom == "nem":
   print("Sajnálom, majd holnap hátha jobb lesz.") 
else:
   print("Ezt nem tudom értelmezni.")   
    
#3 Készíts egy programot! A gép "gondol" egy számra 1 és 5 között, vagyis egy változóban tárolj egy
#ilyen számot! Azután a program bekér egy számot a felhasználótól, majd kiírja, hogy ez a szám egyenlő-e a gép által "gondolt" számmal, vagy annál kisebb, illetve nagyobb.

import random
vSzam = random.randint(1,5)
print(vSzam)
tipp = int(input("Kérem a tipped:"))
if vSzam == tipp:
   print("Talált!")
elif vSzam < tipp:
   print("A vél szám kisebb volt.")   
else:
   print("A vél szám nagyobb volt.")   


    
#7 Készíts alakalmazást, amely bekér egy felhasználónevet és jelszót és ha helyesen, adjuk meg
# akkor írj ki, hogy "Sikeresen bejelentkezél". Ha rosszul adtuk meg akkor írja ki, hogy melyikben
#van a hiba. A helyes felhasználónév: nagymarci11, a helyes jelszó: bodrikutya33

helyesJelszo = "bodrikutya33"
helyesFnev = "nagymarci11"

benev = input("Kérem a felhasználóneved!")
bejelszo = input("Kérem a jelszót!")

if benev == helyesFnev and bejelszo == helyesJelszo:
   print("Siekres bejelnetkezés")
else:
   print("Sikertelen bejelentkezés")   


#10Írj egy Python programot, amely bekér három számot a felhasználótól és kiírja a képernyőre,
#hogy a számok közül bármelyik kettőnek az összege egyenlő-e a harmadik számmal!

#Ágazati 1. típusú
#  1. feladat

elsoSzo = input("Kérem az 1. szót:")
masodikSzo = input("Kérem az 2. szót:")

if len(elsoSzo) > len(masodikSzo):
   print(f"A(z) {elsoSzo} hosszabb, a(z) {masodikSzo} szónál.")
elif len(elsoSzo) < len(masodikSzo):   
   print(f"A(z) {masodikSzo} hosszabb, a(z) {elsoSzo} szónál.")
else:
   print("A két szó egyenlő hosszúságú.")    



#2. feladat
elsoJegy = int(input("Kérem az 1. jegyet: "))  
masodikJegy = int(input("Kérem az 2. jegyet: "))
harmadikJegy = int(input("Kérem az 3. jegyet: "))    

atlag = (elsoJegy + masodikJegy + harmadikJegy) / 3
atlag = round(atlag, 2)

erdemjegy = ""

if atlag < 1.5:
    erdemjegy = "elégtelen"
elif atlag >= 1.5 and atlag <= 2.49:
    erdemjegy = "elégséges"     
elif atlag >= 2.5 and atlag <= 3.49:
    erdemjegy = "közepes"
elif atlag >= 3.5 and atlag <= 4.49:
    erdemjegy = "jó"
else:
    erdemjegy = "jeles"

print(f"A félévi átlagod {atlag}, ezért a félévi osztályzatod {erdemjegy}.")                
    

#3. feladat HF



