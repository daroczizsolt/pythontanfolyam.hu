#Kérjen be egy számot és írassa ki, hogy a szám osztható vagy 3-mal vagy 5-tel

#Adj meg két egész számot egy-egy változóba, és írd ki a kisebbet!

#Írj egy Python programot, amely bekér egy dolgozat pontszámot (x) a felhasználótól és kiír egy
#érdemjegyet az alábbiak szerint! 1: x<50; 2: 50<=x<60; 3: 60<=x<70; 4: 70<=x<85; 5: x>=85.

#Írj egy Python programot, amely bekér három számot a felhasználótól és kiírja a képernyőre,
#hogy a számok közül bármelyik kettőnek az összege egyenlő-e a harmadik számmal!

#Pénzfeldobás modellezése: fej vagy írás? Kérje be a felhasználótól, hogy fejre vagy
# írásra tippel. A gép is válasszon véletlenszerűen egy értékét és írja, ki a nyertest!

# Írj egy Python programot, amely bekér három számot a felhasználótól és kiírja a képernyőre a
#legkisebb értéket ezek közül!

# Háromszög szerkeszthetőség. [Tipp: A háromszög bármely oldalának hossza kisebb a másik két oldal hosszának összegénél.
#Azaz:  a<b+c és  b<a+c és c<a+b 


#+ágazati 3. feladat Pdf-ben csatolva