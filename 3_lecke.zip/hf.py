# 1. Írj programot, mely kiír egy üdvözlő szöveget!

# 2. Írj programot, mely bekéri a felhasználó nevét!

# 3. Írj programot, mely üdvözli a felhasználót, miután megkérdezte a nevét!

# 4. Írj programot, amely összead 2 számot!

# 5. Módosítsad az előző programot úgy, hogy 4 számot tudjunk összeadni!

# 6. Írj programot, amely kiszámolja a téglalap kerületét és területét (a beírt oldalak alapján)!

# 7. Írj programot, amely kiszámolja a háromszög területét (alap és magasság megadása után)!

# 8. A program kérjen be egy vezetéknevet és egy keresztnevet. Üdvözölje a felhasználót!
# a. Vezetéknév - keresztnév sorrendben
# b. Keresztnév - vezetéknév sorrendben

# 9. A program kérjen egy számot, majd írja annak megelőzőjét, illetve rákövetkezőjét!

# 10. A program kérjen be két számot, majd számolja ki azok összegét, különbségét, szorzatát és hányadosát!

# 11. A program kérjen be két változót (a és b)!
# a. Számolja ki az e változó értékét a következő képlet segítségével: e = 2 * a + 3 * b
# b. Számolja ki a d változó értékét a következő képlet segítségével: d = e - 2 * a - 3 * b





