#III. LECKE VÁLTOZÓK és TÍPUSOK / ADATBEKÉRÉS

nev = 'Zsolt' # string - szöveg típusú
print((type(nev)))
kor = 33 # integer - egész típusú érték
print(type(kor))
magassag = 180.2 # float - tört szám
print(type(magassag))
dohanyzik = False # bool - igaz/hamis
print(type(dohanyzik))

print("Az én nevem:",nev,"a korom:", kor)
print(f"{nev}-nak hívnak {kor} éves vagyok és {magassag} cm.")

kor = 34
print(f"{nev}-nak hívnak {kor} éves vagyok és {magassag} cm.")

# egészes osztás
print(10//4)
# hatványozás
print(5**2)

#Kerület terület számítások

# négyzet K T

a = 12
K = a*4
T = a*a
print(f"A négyztet Kerülete: {K}, és a területe {T}")

# téglalap K T

# kör K T 

#Tárolj el 2 számot egy-egy változóba, melyek egy derékszögű háromszög befogói. Mekkora az átfogója? 
import math
a = 4
b = 6
# a2 + b2 = c2
c2 = (a**2) + (b**2)
c = math.sqrt(c2)

#kerekítés
#c = round(c, 3) # kerekítés matematikailag, n- tízedes jegyre
#c = math.ceil(c) # felfelé kerekítés
c = math.floor(c) # lefelé kerekítés
print(c)

# string műveletek

szoveg = "cipőfűző"
print(szoveg[:6])

# karakterek száma
szovegKSzam = len(szoveg)
print(szoveg.capitalize())
print(szoveg.upper())
print(szoveg.lower())

#típuskonverziók - típusátalakítás

number = "12561"
print(len(number))
number = int(number)
print(number+2)

last = "Daroczi "
first = "Zsolt"
nick = last+first
print(nick)

#Interaktivitás - adatbekérés

szuletesiEv = int(input("Kérem a születési éved:"))
print((szuletesiEv))
kor = 2025 - szuletesiEv
print(kor)


# Tárolj el 3 tantárgyat a jegyekkel egy-egy változóba! Írd ki a számtani közepüket!

matek = 4
töri = 5
fizika = 3
atlag = (matek + töri + fizika)/3
print(atlag)


csillagdb = int(input("Hány csillagot adsz Andrisnak?"))
print(csillagdb * "*")


# Készítsen festékkalkulátor programot. Kérje be a felhasználótól a falfelület(m2) méretét. 
# A felületet két sorral szeretnénk festeni. 1l festék  15m2 falfelületre elegendő.
# A válaszát f string-ben adja meg az alábbiak szerint:
#pl: 1 liter festék szükséges 15 m2 falfelület kifestésére 2 rétegben.

falfelulet = float(input("Falfelulet:(m2)")) 
festekSzukseglet = falfelulet / 15
print(f"{festekSzukseglet*2} liter festék szükséges a {falfelulet} m2 falfelület kifestésére 2 rétegben.")





