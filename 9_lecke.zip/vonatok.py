megallok = [] 
f = open("vonatok.txt", "r", encoding="utf-8")

for sor in f: # sor = "Budapest-Nyugati;180;220;0"
    megallo = sor.strip().split(";")
    megallo[1] = int(megallo[1])
    megallo[2] = int(megallo[2])
    megallo[3] = int(megallo[3])
    megallok.append(megallo)
f.close()

#print(megallok)
print('2. feladat')
print("Megállók száma", len(megallok)-2)

print('3. feladat')
utasokSzama = 0
for i in megallok: #i = ['Budapest-Nyugati', 180, 220, 0]
    utasokSzama += i[2]
print(f"Összesen {utasokSzama} utas vette igénybe a vonatot aznap.")  

print('4. feladat')
utasokDB = []
aktualisUtasokSzama = 0
for i in megallok:
    aktualisUtasokSzama += i[2] - i[3]
    utasokDB.append(aktualisUtasokSzama)
    print(f"{i[0]} állomás: {aktualisUtasokSzama} utas.")

print(utasokDB)
print("5. feladat")

ugyanAnnyiFelLe = False
ugyanAnnyiAllomas = ""

for i in megallok:
    if i[2] == i[3]:
        ugyanAnnyiFelLe = True
        ugyanAnnyiAllomas = i[0]
if ugyanAnnyiFelLe:
       print(f"{ugyanAnnyiAllomas} állomáson, ugyanannyian szálltak le, mint fel.")  
else:
     print("Nem volt olyan állomás, ahol ugyanannyian szálltak le, mint fel.")
               
        
print("6. feladat")
maxFelszallo = megallok[1][2] # 25
maxAllomas = ""
for i in megallok[1:]:
     if i[2] > maxFelszallo:
          maxFelszallo = i[2]
          maxAllomas = i[0]

print(f"A legtöbben {maxAllomas} állomáson szálltak fel.")

print("8.feladat")



# UtasokDb [220, 235, 262, 282, 297, 212, 217, 222, 172, 155, 155, 126, 0]



def kapacitas(ertek, kap=300):
     szazalek = (ertek / kap) * 100
     return round(szazalek,2)

for i in range(len(utasokDB)): #0-13
     k = kapacitas(utasokDB[i]) #220
     if k > 80:
          print(f"{megallok[i][0]} {k} kapacitással indult tovább.")
          
fki = open("statisztika.txt", "w", encoding='utf-8')

for i in megallok:
     utasf = abs(i[2]-i[3])
     if utasf < 20:
          print(f"{i[0]}: Alacsony forgalmú", file=fki)
     elif 20 <= utasf < 50:
           print(f"{i[0]}: Közepes forgalmú", file=fki)
     else:
          print(f"{i[0]}: Kiemelt forgalmú", file=fki)  
             
fki.close()    

     










