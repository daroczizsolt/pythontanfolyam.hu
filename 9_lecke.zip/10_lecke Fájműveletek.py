#Fájlbeolvasás 
#1. eset

f = open("gyumolcsok_1.txt", "r", encoding="utf-8")

beolvasva = f.readline()
f.close()
print(beolvasva)
# "körte,alma,banán,málna,eper,szőlő,erdeigyümölcs,avokádó,citrom,narancs"
be_szeletelve = beolvasva.split(",")
print(be_szeletelve)

#1.eset, ha számokat kell beolvasni
f = open("szamok_1.txt", "r")
szamokBe = f.readline()
szamokList = szamokBe.split(";")
print(szamokList)



#a verzio
konvertmap = list(map(int, szamokList))
print(konvertmap)

#b verzio
# szamokIntlist = []
# for i in szamokList:
#     szamokIntlist.append(int(i))
# print(szamokIntlist)


#2. eset

f = open("gyumolcsok_2.txt", "r", encoding="utf-8")

#a verzio
# bevolasWs = []

# beolvas = f.readlines()

# print(beolvas)

# for i in beolvas:
#     bevolasWs.append(i.strip())
# print(bevolasWs)

#b 
gyum = []
for sor in f:  #körte\n 
    sor = sor.strip() # körte
    gyum.append(sor)
f.close()
#print(gyum)

#3 eset. Amikor több sorunk van a txt-ben és soronként több adat, valamilyen karakterrel elválasztva

# gyumolcsok = [
#     ['körte', 'Ázsia', 4],
#     ['alma', 'Ázsia', 8],
#     ...
# ]
f = open("gyumolcsok_3.txt", "r", encoding="utf-8")
gyumolcsok = []
f.readline() # az első sort beolvasásást kihagyjuk

for sor in f: #sor = "körte; Ázsia; 4"
    kislista = sor.split(";") #  ['körte', 'Ázsia', '4']
    kislista[2] = int(kislista[2])
    gyumolcsok.append(kislista)
f.close()



#Fájlkiírása
#print(gyumolcsok)
fki = open("magasCvitamin.txt", "w", encoding="utf-8")
for i in gyumolcsok: #['körte', ' Ázsia', 4]
    if i[2] > 50:
        #print(f"{i[0]}: {i[2]} g / 100g C Vitamin tartalom.",file=fki)
        fki.write(f"{i[0]}: {i[2]} g / 100g C Vitamin tartalom.\n")
