# 1. Írj egy programot, amely kiírja az összes páratlan számot 1 és 50 között!

# 2. Írj egy programot, amely bekér egy számot (n), majd kiírja az 1-től n-ig terjedő számokat visszafelé!

# 3. Írj egy programot, amely addig kér be számokat a felhasználótól, amíg az 100-at nem ír be!

# 4. Írj egy programot, amely egy véletlenszámot generál 1 és 20 között, 
#    majd a felhasználónak ki kell találnia! Addig találgathat, amíg el nem találja!

# 5. Írj egy programot, amely 10 véletlenszámot generál 1 és 100 között, 
#    és csak a 30-nál nagyobbakat írja ki!

# 6. Írj egy programot, amely addig generál véletlenszámokat 1 és 50 között, 
#    amíg nem kapunk egy 25-nél kisebb számot!