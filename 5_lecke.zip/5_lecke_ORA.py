"""
#V. lecke ISMÉTLÉSEK, CIKLUSOK

# FOR CIKLUS

for i in range(21,2,-2):
    print(i, "hello")
    print("asdasd")


# Írj egy programot, amely kiírja a számokat 1-től 10-ig egymás alá!

# Írj egy programot, amely 10 véletlenszerű számot generál 1 és 100 között, és kiírja őket egymás alá!

import random
for i in range(1,10):
    velSzam = random.randint(1,100)
    print(f"{i}.szám: {velSzam}")



# Írj egy programot, amely 15 véletlenszerű számot generál 1 és 50 között,
#  és csak azokat a számokat írja ki, amelyek páratlanok!

import random
for i in range(1,16):
    velSzam = random.randint(1,50)
    if velSzam % 2 == 0:
      print(f"{i}.szám: {velSzam}")


# Írj egy programot, amely kiírja a páros számokat 2 és 50 között!

# Írj egy programot, amely bekér egy pozitív egész számot (n), majd kiírja az 1-től n-ig terjedő számok négyzeteit!

n = int(input("Kérem a felső határéréket!")) 
for i in range(1, n):
   negyzetSzam = i*i
   print(negyzetSzam)


# Írj egy programot, amely 10 véletlenszerűen generált számot vizsgál. Ha egy szám páros, írd ki, hogy "Páros", ha páratlan, írd ki, hogy "Páratlan"!


#Írj egy programot vagy scriptet, ami 1-től 100-ig kiírja a számokat.
#  Ha a szám osztható hárommal, akkor írja ki a szám helyett, hogy Fizz,
#  ha osztható öttel, akkor Buzz, ha mind a kettővel osztható, akkor FizzBuzz.
# ha egyikel sem, akkor a számot.

for i in range(1,101): # 15
   if i % 5 == 0 and i % 3 == 0:
      print("FizzBuzz")
   elif i % 3 == 0:
      print("Fizz")
   elif i % 5 == 0:
      print("Buzz")
   else:
      print(i)         


# WHILE CIKLUS
szamlalo = 1
while szamlalo < 11: # 1
   print(szamlalo)  # 1
   szamlalo = szamlalo + 1 # - > 11

#fekvőtámasz
szamlalo = 1
faradtsag = "nem"
while faradtsag != "igen":
   print(f"{szamlalo}. fekvőtámasz")
   faradtsag = input("Elfáradtál? (igen/nem)")
   szamlalo += 1

szamlalo = 1
faradtsag = "nem"
while True:
   print(f"{szamlalo}. fekvőtámasz")
   faradtsag = input("Elfáradtál? (igen/nem)")
   if faradtsag == "igen":
      break 


# Számlálós `while` ciklus: 1-től 10-ig kiírja a számokat.
# A felhasználó addig ad be számokat, amíg 0-t nem ír be.
# Random számok generálása: Véletlenszerű számok generálása 1 és 100 között,
#  addig amíg a szám nagyobb nem lesz 90.
import random
while True:
   velSzam = random.randint(1,100)
   if velSzam > 90:
      break
   else:
      print(velSzam)


# Felhasználói jelszó ellenőrzése: A felhasználó addig adhatja meg a jelszót, amíg helyeset nem ír be.
# Véletlenszerű szám kitalálós játék: A gép választ egy számot, a felhasználónak ki kell találnia
# Addig találgathasson amíg ki nem találja.
 

import random
gepSzam = random.randint(1,5)
while (tipp := int(input("Kérem a tipped(1-5)"))) != gepSzam:
   print("Nem talált")
print("Talált")

# Felhasználó által megadott számok átlaga: A felhasználó addig adhat számokat, amíg 0-t nem ad meg, majd kiírjuk az átlagot.
# Véletlenszámok, amíg nem találunk páros számot: Véletlenszerű számokat generálunk, és addig folytatjuk, amíg nem találunk egy páros számot.
"""
szamlalo = 4
while szamlalo > 3:
    print(szamlalo)
    szamlalo += 1