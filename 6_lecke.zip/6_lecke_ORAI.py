#VI. Lecke összetett adatszerkezetek: listák

kacatok = ["gombolyag", "fonal", "ceruza","ceruza", "toll"]
print(kacatok[2:-2])

#listához tartozó beépített függvények (append, len, insert, remove, pop, index, count, sort
#reverse)

kacatok.append("cipőfűző")

kacatok.insert(0, "hegyező")

kacatok.remove("hegyező")
kacatok.pop()

szamok = [3, 5, 10, 20, 2, 1]
novLista = sorted(szamok, reverse=True)
print(novLista)

print(szamok.count(10))

print()

#listák bejárásának lehetőségei: 
for i in szamok:
    if i % 2 != 0: 
      print(i)


#Az adott lista elemei közül a program kiírja a "t" és "T"
#betűkkel kezdődőeket! 

szavak = ['ajtó','tojás','Ottó','Tamás', 'tép','Tesla','alma','python'] 

for i in szavak: # i = ajtó
   if i[0] == "t" or i[0] == 'T':
      print(i)
      break

print(szavak[0][0])      


# lista feltöltés n darab véletlenszámmal (0, 100) között
import random
vSzamok = []
n = int(input("Hány véletlen számot kérsz a listába?")) # 10000
for i in range(n):
   v = random.randint(0,10) # 5
   if v not in vSzamok:
      vSzamok.append(v)
print(vSzamok)

vSzamok2 = [random.randint(0,10) for _ in range(n)]
print(vSzamok2)


#lista feltöltés a felhasználó álltal addig amíg 0- t nem ír be a felhasználó. 
numbers = []
while True:
   n = int(input("Kérek egy számot"))
   if n != 0:
      numbers.append(n)
   else:
      break   
print(numbers) 


numbers2 = []
k = int(input("Kérek egy számot"))
while k != 0:
   numbers2.append(k)
   k = int(input("Kérek egy számot"))
print(numbers2)

#egy listahossza vagy hány értéket tartalmaz

print(len(numbers2))

import random
vSzamok2 = [random.randint(0,100) for _ in range(20)]

#Lista bejárás, miközben tudni akarom, hogy az adott elem hányadik helyen van a listában!

for i, j in enumerate(vSzamok2): # i = 0......19
   print(f"{i+1}. szám: {j}")

for i in range(len(vSzamok2)): #i = 1
   print(i+1, vSzamok2[i]) 

for i in vSzamok2:
   print(vSzamok2.index(i),i) 

for i, j in enumerate(vSzamok2): 
   if j % 2 == 0:
      print(f"{i+1}. szám: {j}")

# 2D listák mátrixok

#az adott tanulóknak mennyi lett az átlaga?
tanulok = [
   [4,4,5,3,5,3,3,5],
   [2,4,4,3,5,3,2,5],
   [1,4,5,3,2,3,3,5],
   [5,5,5,5,5,5,5,5],
   [2,4,5,5,5,3,1,5],
   ]
#sum() / len()   
print(tanulok) 
for i in tanulok:  #i = [4,4,5,3,5,3,3,5]
   print(sum(i)/len(i)) 
  











    




