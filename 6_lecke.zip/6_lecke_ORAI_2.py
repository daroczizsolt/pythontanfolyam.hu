# Szótár létrehozása – kulcs-érték párok használata


# Szótár elemeinek elérése


# Elem hozzáadása és módosítása


# Elem törlése


# Szótár bejárása



# Alapvető metódusok


# Több elem hozzáadása


# Szótár törlése



#Kérjünk be egy szót és aztán nézzük meg, hogy az található-e a szótárban, és ha igen, akkor írjuk ki az értékét.

        
# egy gyakorlati példa szótárakhoz. Töltsük fel 5 db elemmel egy szótárat egy raktárban található elemekkel. A kulcsok az
# áru neve az értéke a áruhoz tartozó darabszám


