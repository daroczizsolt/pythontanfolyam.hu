autok = [
    ["Toyota", "fekete", 40, 10, 7.2],
    ["Mazda", "piros", 35, 10, 6],
    ["Ford", "fehér", 40, 10, 7.1],
    ["Suzuki", "zöld", 30, 10, 6.2],
]

class Auto: # osztály -> sablon
    def __init__(self, marka, szin, tankmeret, benzinMennyiseg, fogyasztos ): # konstruktor 
        self.marka = marka
        self.szin = szin
        self.tankmeret = tankmeret
        self.benzinMennyiseg = benzinMennyiseg
        self.fogyasztas = fogyasztos

    def Tankolas(self, benzinM):
        if benzinM + self.benzinMennyiseg > self.tankmeret:
            return False
        else:
            self.benzinMennyiseg += benzinM
            return True  
        
    def Utazas(self, uthossz):
        szukseges_benzin = (uthossz * self.fogyasztas) / 100
        if szukseges_benzin <= self.benzinMennyiseg:
            self.benzinMennyiseg -= szukseges_benzin
            return f"A(z) {self.marka} sikeresen teljesítette a {uthossz} km távolságot. ({self.benzinMennyiseg} maradt még a tankban.)"
        else:
            return f"A(z) {self.marka} -ban nincs elég üzemenyag a {uthossz} km táv megtételéhez."    
        
     

"""
auto_1 = Auto("Toyota", "fekete", 40, 10, 7.2) # példányosítottam -> objektum
print(auto_1.marka, auto_1.szin)

auto_2 = Auto("Mazda", "kék", 39, 10, 6.8)
print(auto_2.marka, auto_2.szin)
"""

f = open("autok_lista.txt", "r", encoding="utf-8")
# autok = [obj1(marka = "Toyota", szin="fekete", tankmeret=40, benzinmennyiseg=10,fogyasztas=7.2 ),
#          obj2 (marka = "Ford",)]

autok = []

for i in f: #i = "Toyota;fekete;40;10;7.2" 
    auto = i.strip().split(";") # ["Toyota", "fekete", '40', '10', '7,2']
    auto[2] = int(auto[2])
    auto[3] = int(auto[3])
    auto[4] = float(auto[4])
    a = Auto(auto[0], auto[1], auto[2], auto[3], auto[4])
    autok.append(a)
    
print(autok)

for i in autok:
    print(i.Utazas(300))
    




"""
class Karakter:
    def __init__(self, nev, kinezet):
        self.nev = nev
        self.kinezet = kinezet
        self.eletero = 100
        self.sebzesero = 10

k1 = Karakter("Karakter1", "droid")
print(k1.nev, k1.kinezet, k1.eletero, k1.sebzesero)

k2 = Karakter("Karakter2", "halálharcos")
print(k2.nev, k2.kinezet, k2.eletero, k2.sebzesero)
"""

        


























