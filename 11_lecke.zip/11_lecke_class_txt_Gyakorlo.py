class Konyv:
    def __init__(self, cim, szerzo, ar, kategoria):
        self.cim = cim
        self.szerzo = szerzo
        self.ar = ar
        self.kategoria = kategoria
        self.eladas = 0
        self.bevetel = 0

    def EladasGeneralas(self):
        import random
        return random.randint(50,300)
    
    def BevetelSzamitas(self):
         self.bevetel = self.eladas * self.ar
         


f = open("konyvesbolt.txt", "r", encoding="utf-8")
konyvek = []
for i in f:
    konyv = i.strip().split(";")
    konyv[2] = int(konyv[2])
    k = Konyv(konyv[0], konyv[1], konyv[2], konyv[3])
    k.eladas = k.EladasGeneralas()
    k.BevetelSzamitas()
    konyvek.append(k)

f.close()
fki = open("eladasok.txt", "w", encoding="utf-8")
for i in konyvek:
    print("Könyv címe:", i.cim, file=fki)
    print("Szerző:", i.szerzo, file=fki)
    print("Kategoria:", i.kategoria, file=fki)
    print("Eladott példányszám:", i.eladas, file=fki)
    if i.bevetel > 1_000_000:
      print("Bevétel:", i.bevetel, file=fki)
      print("BESTSELLER", file=fki)
    else:
      print("Bevétel:", i.bevetel, file=fki)

    print("-------------------------------------", file=fki)  
          
fki.close()             


        