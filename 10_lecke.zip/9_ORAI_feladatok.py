# def osszead(a, b):
#     eredmeny = a + b
#     return eredmeny

# eredmeny = osszead(5, 3)
# print("Az összeg:", eredmeny)
# print("Újabb összeg:", osszead(9,2))

#Függvény, amely a felhasználó álltal magadott műveletet hajt végre két számmal.
"""
def szamolo(a, b, muvelet):
   if muvelet == "+":
      return a * b
   elif muvelet == "-":
      return a - b
   elif muvelet == "*":
      return a * b
   elif muvelet == "/":
      return a/b
   else:
      return "Nincs ilyen műveleti jel."    

for i in range(5):
   szam1 = int(input("Kérem az 1. számot:")) #7
   szam2= int(input("Kérem az 2. számot:")) # 2
   mjel = input("Kérem a műveleti jelet:") # +

   print(szamolo(szam1,szam2,mjel))              

#Eljárás, amely annyi csillagot rajzol a képernyőre, amennyit a felhaszáló magad.

def csillagRajzol(j):
   print("*"*j)

jutalom = int(input("Kérem a * jutalom számát!"))
csillagRajzol(jutalom)

#Faktoriális függvény:
#4! = 4*3*2*1 = 24

def fakt(szam): # 4
    szorzat = 1
    for i in range(szam, 0, -1): #1
         szorzat = szorzat * i # szorzat = 24*1 = 24
    return szorzat  

befakt = int(input("Miből számoljak fakt: "))
print(fakt(befakt))


#Eljárás, amely egy 100 db -os listából statisztikát végez: 
# - számok összege
# - számok átlaga
# - páros számok darabszám
# - van e- 5-tel és 3 mal osztható
# - legnagyobb érték

import random

def statisztika(lista):
   print("A listában lévő számok összege:",sum(lista))
   print("A listában lévő számok átlaga:",sum(lista)/len(lista))
   print(f"A listában {lista.count(5)} db 5 szám található.")
   parosdb = 0
   for i in lista:
      if i % 2 == 0:
         parosdb += 1
   print(f"A listában {parosdb} db páros szám található.")   
   print("A legnagyobb szám a listában", max(lista))   


vSzamok = [random.randint(1,40) for i in range(100)]
statisztika(vSzamok)


#Függvény amely elemez egy mondatot, hogy helyesen van-e írva? -> visszatérési értéke legyen Bool
# - a mondat kezdőbetűje nagybetűs
# - a végén van mondatvégi írásjel
# - a szavak között pontosan egy db szóköz van
"""
def helyesMondat(mondat):
   nagybetus = [
    "A", "Á", "B", "C", "D", "E", "É", "F", "G", "H", "I", "Í", "J", "K", "L", "M", 
    "N", "O", "Ó", "Ö", "Ő", "P", "Q", "R", "S", "T", "U", "Ú", "Ü", "Ű", "V", "W", 
    "X", "Y", "Z"
   ]  
   irasjelek = [".", "!", "?"]
   kezdobetu, irasjel, szokoz = False, False, False
   # if mondat[0] in nagybetus:
   #    kezdobetu = True
   if mondat[0].isupper() == True:
      kezdobetu = True
   if mondat[-1] in irasjelek:
      irasjel = True
   for i in range(len(mondat)-1): #Géza kék az ég!  
       if mondat[i] == " ":
          if mondat[i+1] == " ":
             return False 
          szokoz = True   
   
   if kezdobetu and irasjel and szokoz:
      return True
   else:
      return False    

print(helyesMondat("Géza kék az ég!"))      




