
def mozilatogatas(kor):
   if kor >= 16:
      return True
   else:
      return False 

szamlalo = 1
while True:
   fkor = int(input(f"Kérem az {szamlalo}. néző életkorát:"))
   if fkor == 0:
      break
   else:
      if mozilatogatas(fkor):
         print(f"A(z) {szamlalo}. néző megnézheti a filmet.")
        
      else:
          print(f"A(z) {szamlalo}. néző nem nézheti meg a filmet.")
   szamlalo += 1 


def kvautomata(kvneve, tej):
   if kvneve == "espresso" and tej == "nem":
      return "Elkészíthető."
   elif kvneve == "espresso" and tej == "igen":
      return "Nem készíthető el."   
   elif (kvneve == "cappuccino" or kvneve == "latte") and tej == "igen":
      return "Elkészíthető." 
   elif (kvneve == "cappuccino" or kvneve == "latte") and tej == "nem":
      return "Nem készíthető el."   

while True:
   kv = input("Kérem a kívánt kávét (espresso/cappuccino/latte):")
   if kv == "kilép":
      break
   else:
      t = input("Tejjel kéri? (igen/nem):")
      print(kvautomata(kv, t))


def mondatellenorzo(mondat):
   irasjelek = ['.', '?', '!']
   if mondat[-1] in irasjelek and mondat[0].isupper():
      return "Helyes mondat."
   else:
      return "Helytelen mondat."   

for i in range(3):
   m = input("Kérem a mondatot: ")
   print(mondatellenorzo(m))


def filmekbeker():
   filmcimek = []
   while True:
      fcim = input("Kérem a film címét:")
      if fcim == "":
         break
      else:
         filmcimek.append(fcim.upper())
   return filmcimek


filmek = filmekbeker()

def elemzes(lista):
   print(f"{len(lista)} film került rögzítésre.")
   db = 0
   for i in lista:
      if i[0:4] == "STAR":
         db += 1 
   print(f"STAR szóval {db} film kezdődik.")
   print("Rögzített filmek: ", end="")
   for i in lista:
      print(i, end=" | ")

elemzes(filmek)

