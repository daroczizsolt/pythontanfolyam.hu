#1. feladat

megallok = [10, 18, 30, 50, 43, 41, 42, 32, 32, 8]

kapacitas = 50
import math
szamlalo = 1
print("2. feladat")
for i in megallok: # i = 10
   if i < 20:
      print(f"{szamlalo}. megálló után: {i} utas, {kapacitas - i} szabad hely – Sok szabad hely van!")
   elif i == 50:
      print(f"{szamlalo}. megálló után: {i} utas, NINCS több szabad hely!")
   else:
      print(f"{szamlalo}. megálló után: {i} utas, {kapacitas - i} szabad hely!")      
   szamlalo += 1

atlag_utasok = sum(megallok) / len(megallok)
atlag_utasok = math.ceil(atlag_utasok)
print("3. feladat")
print(f"A busz átlagos telítettsége az út során: {atlag_utasok} utas.")

print("4. feladat")
#megallok = [10, 18, 30, 50, 43, 41, 42, 32, 32, 8]

megallok = [10, 18, 30, 50, 43, 43, 42, 44, 32, 8]

csokkono_sorozat = 0
voltKetCsokkenes = False
for i in range(1, len(megallok)-2): #1-7
   if megallok[i] < megallok[i-1]:
      csokkono_sorozat += 1
   else:
      csokkono_sorozat = 0  

   if csokkono_sorozat >=2:
      voltKetCsokkenes = True
      break   
if voltKetCsokkenes:
   print("Volt legalább két egymást követő megálló, amikor csökkent az utasok száma.")
else:
   print("Nem volt legalább két egymást követő megálló, amikor csökkent az utasok száma.")   

#------------------------------------------------



#2. feladat


abc= ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", 
    "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]

szamok = [20, 27, 6, 5, 14, 26, 12, 22, 18, 9, 25, 5, 16, 1, 25, 3, 17, 5, 20, 2]
#print(len(szamok))
#1. betű
betu1 = abc[szamok[0]-1]
#print(betu1)

#2. betű
legnagyobb = szamok[0]
index  = 0
for i, j in enumerate(szamok):
   if j > legnagyobb:
      legnagyobb = j
      index = i
betu2 = abc[index]

nagy = max(szamok)
nagyHelye = szamok.index(nagy)
betu2 = abc[nagyHelye]
#print(betu2)

#3. betű
keresett = szamok.index(17)+1
betu3 = abc[keresett]
#print(betu3)

#4. betű
egyszj = []
for i in szamok:
   if len(str(i)) == 1:
      egyszj.append(int(i))
eredmeny = sum(egyszj) - 22
betu4 = abc[eredmeny]
#print(betu4)

#Külön add össze a páros helyeken és a páratlan helyeken álló számokat.
#A két összeg különbségének számjegyeit add össze, majd az így kapott számot használd az abc listában indexként!
paros, paratlan = 0,0
for i, j in enumerate(szamok):
   if i % 2 == 0:
      paros += j
   else:
      paratlan += j   
kulonbseg = paros - paratlan
#print(kulonbseg)

kulonbseg = str(kulonbseg)
osszeg  = 0
for i in kulonbseg:
   osszeg += int(i)
betu5 = abc[osszeg-1]
#print(betu5)

print("A frigylád kódja:", betu1+betu2+betu3+betu4+betu5)

#------------------------------------------------


#3. feladat
napok = []

napok = [2500, 2400, 2350, 2300, 2100, 2000, 2000]


# nap = 1
# for i in range(7):
#     kcal = int(input(f"{nap}. nap kalóriabevitele:"))
#     napok.append(kcal)
#     nap += 1

csalonapok = []
for i in range(1, len(napok)):  # 
    if napok[i] > napok[i-1] - 100:
        csalonapok.append(i+1)
print(csalonapok)        
        
if napok[-1] <= 1900 and len(csalonapok) == 0:
    print("Minden nap tudta tartani az ütemtervet és elérte a célját!")
elif napok[-1] <= 1900 and len(csalonapok) != 0:
    print("A versenyző elérte a célját, de nem minden nap sikerült pontosan betartani a 100 kcal csökkentést.") 
    print("Nem sikerült tartani az ütemtervet a következő napon: ", end="")  
    for i in csalonapok:
        print(i, end=",")
else:
    print("A versenyző nem elérte a célját.")
    print("Nem sikerült tartani az ütemtervet a következő napon: ", end="") 
    for i in csalonapok:
        print(i, end=",")
#------------------------------------------------

#4. feladat

import random
angol_szavak = ["apple", "house", "dog", "car", "tree"] 
magyar_szavak = ["alma", "ház", "kutya", "autó", "fa"]

találatok = 0

while True:
   angol = random.choice(angol_szavak) 
   magyar = input(f"Mit jelent a {angol} szó?") 
   találatok += 1     

   if magyar in magyar_szavak:  

      angol_Helye = angol_szavak.index(angol) 
      magyar_Helye = magyar_szavak.index(magyar)

      if angol_Helye == magyar_Helye:
         print("Helyes!")
         del angol_szavak[angol_Helye]
         del magyar_szavak[magyar_Helye]
      else:
         print("Helytelen!")  

      if len(angol_szavak) == 0:
         break
   else:
      print("Helytelen szó!")   

print(f"Gratulálok, sikerült {találatok} próbálkozásból kitalálnod az 5 szót")

      




    
     
    
       







