
cars = [
    ["Toyota", "ABC-123", 6.5, 40],
    ["Opel", "XYZ-789", 7.2, 35],
    ["Kia", "RST-456", 5.8, 45],
    ["Ferrari", "FERR-1", 12.5, 20],
    ["Opel", "OPL-555", 7.0, 30]
]
"""
for i in range(5): # i = 1
   tipus = input(f"Kérem az {i+1} autó típusát:")
   rszam = input(f"Kérem az {i+1} autó rendszámát:")
   fogyasztas = float(input(f"Kérem az {i+1} autó fogyasztását (l/100km):"))
   szint = input(f"Kérem az {i+1} autó üzemenyag szintjét:")
   car = [tipus, rszam, fogyasztas, szint]
   cars.append(car)
"""

print("2. feladat")
print("Autók listája")
s = 1
for i in cars: # i = ["Toyota", "ABC-123", 6.5, 40]
   print(f"{s}. Típus: {i[0]}, Rendszám: {i[1]}, Fogyasztás: {i[2]} Üzemanyagszint: {i[3]}")
   s += 1

talalt = False
while not talalt:
   rszam = input("Adja meg az autó rendszámát, amellyel utazni szeretne")
   for i in cars:
      if rszam == i[1]:
         talalt = True
         break
   else:
      print("Nincs ilyen autó! Kérem, adjon meg egy létező rendszámot!")

km =  int(input("Hány kilométert szeretne utazni? "))
for i in cars:
   if rszam == i[1]:
      fogyasztas_km = (i[2]/100)*km
      print(fogyasztas_km)
      print(i[3])
      if fogyasztas_km <= i[3]:
         print("Az út megtehető")
      else:
         print("Az úthoz nincs elengedő üzemanyag az autóban.")   


print("3. feladat")
osszeg = 0
for i in cars: #i ["Opel", "XYZ-789", 7.2, 35]
   osszeg += i[-1]
print("Összüzemanyagszint:", osszeg," liter") 
print("Átlag üzemanyagszint:", round(osszeg/len(cars)), "liter")  


legmagasabb = cars[0][-1] # 40
hely = 0
for index, ertek in enumerate(cars): #index = 2, ertek = ["Kia", "RST-456", 5.8, 45]
   if ertek[-1] > legmagasabb:
      legmagasabb = ertek[-1] # 45
      hely = index # 2

print("Az autónak, amelynek a legmagasabb az üzemanyagszintje:")
print(f"Típus: {cars[hely][0]}, Rendszám: {cars[hely][1]}, Fogyasztás: {cars[hely][2]} l/100km, Üzemanyagszint: {cars[hely][3]} liter")

Kia = False
for i in cars:
   if i[0] == "Kia":
      Kia = True
      break
if Kia:
   print("Van Kia a listában.")
else:
   print("Nincs Kia a listában")   


Ferrari = False
for i in cars:
   if i[0] == "Ferrari":
      Ferrari = True
      print("Ferrari első fogyasztása:", i[2], "l/km.")  
      print("Ferrari első rendszáma:", i[1])
      break
if not Ferrari:
   print("Nincs Ferrari a listában")

dbObel = 0
for i in cars:
   if i[0] == "Opel":
      dbObel += 1
print(f"Hány Opel van? {dbObel} db")      


legalacsonyabb = cars[0][2] # 40
hely = 0
for index, ertek in enumerate(cars): #index = 2, ertek = ["Kia", "RST-456", 5.8, 45]
   if ertek[2] < legalacsonyabb:
      legalacsonyabb = ertek[2] # 45
      hely = index # 2
print("Az autónak, amelyiknek a legalacsonyabb a fogyasztása:")      
print(f"Rendszám: {cars[hely][1]}, Fogyasztás: {cars[hely][2]} l/100km")  


maxfogy = cars[0][2] # 40
hely = 0
for index, ertek in enumerate(cars): #index = 2, ertek = ["Kia", "RST-456", 5.8, 45]
   if ertek[2] > maxfogy:
      maxfogy = ertek[2] # 45
      hely = index # 2    
print(f"A legmagasabb fogyasztás: {cars[hely][2]} l/100km")


minszint = cars[0][-1] # 40
hely = 0
for index, ertek in enumerate(cars): #index = 2, ertek = ["Kia", "RST-456", 5.8, 45]
   if ertek[-1] < minszint:
      minszint = ertek[-1] # 45
      hely = index # 2
print(f"A legalacsonyabb üzemanyagszint: {cars[hely][-1]} liter")      


