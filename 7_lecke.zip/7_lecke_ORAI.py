szamok = [15,2,30,42,22,16,35,5,4,20,67,99]
"""
#ÖSSZEGZÉS
# Az adatsor elemeit végigjárva egy összegző változó segítségével
# kiszámítjuk a lista elemeinek összegét (vagy egy adott tulajdonságnak megfelelő értékek összegét).
# PL: Egy lista elemeinek összege.
osszeg = 0
for i in szamok: 
   if i % 2 == 0:
      osszeg = osszeg + i 
print(osszeg)

#MEGSZÁMLÁLÁS
#Megszámolja, hogy hány darab bizonyos tulajdonságú elem található az adatsorban.
#Hány páros szám van egy listában?
szamlalo = 0
for i in szamok: # 30
   if i % 2 == 0: #0
      szamlalo += 1 # 2
print(szamlalo)
print("-------------------")

#ELDÖNTÉS
#Azt vizsgálja, hogy az adatsor tartalmaz-e egy bizonyos tulajdonságú elemet.
#PL: Van-e hárommal osztható szám a listában?
harom = False
for i in szamok: #i 15
   if i % 3 == 0: # IGAZ
      harom = True
      break

if harom:
   print("Van hárommal osztható szám a listában.")
else:
   print("Nincs hárommal osztható szám a listában.")   


#Annak meghatározása, hogy egy (adott elem) hányadik helyen található a listában?
szamok = [15,2,30,42,22,16,35,5,4,20,67,99]

for index, ertek in enumerate(szamok): 
   print(index+1, ertek)
print("---------------------")
for i in range(0,len(szamok)): # 1
   print(i, szamok[i]) #szamok[1]


#KIVÁLASZTÁS
#Azt határozza meg, hogy egy bizonyos tulajdonságú elem hol található a listában,
#feltételezve, hogy létezik ilyen elem.
#PL: Hol található az első hárommal osztható szám a listában?
szamok = [2,2,30,42,22,16,35,5,4,20,67,99]

for index, ertek in enumerate(szamok):
   if ertek % 3 == 0:
      print(index+1, ertek)
      

"""
#KERESÉS
#Megkeresi egy adott tulajdonságú elem helyét a listában, de nem biztos, hogy létezik ilyen elem.
#Melyik indexen van a "piros" szín a listában? (Ha nincs, akkor ezt jelezzük.)
szinek = ["sárga", "zöld", "narancs","kék", "fekete", "fehér"]

piros = False
for i in range(len(szinek)):
   if szinek[i] == "piros":
      piros = True
      print(i+1, szinek[i])
      break
if piros == False:
   print("Nincs piros szín a listában.")
 

#KIVÁLOGATÁS
#Az adatsor bizonyos feltételnek megfelelő elemeit külön listába gyűjti.
#PL: Példa: Egy új listába összegyűjtjük a páros számokat.
szamok = [15,2,30,42,22,16,35,5,4,20,67,99,2,22,16]
paros_szamok = []
for i in szamok:
   if i % 2 == 0 and i not in paros_szamok:
      paros_szamok.append(i)
print(paros_szamok)
    
#SZÉLSŐ ÉRTÉK
#A legkisebb vagy legnagyobb értékű elemet keresi meg az adatsorban.
#Hányadik helyen van a legkisebb és legnagyobb elem?

legnagyobb = szamok[0] #15
hely = 0
for index, ertek in enumerate(szamok): # 22
   if ertek > legnagyobb:# 22 > 42
      legnagyobb = ertek # legnagyobb = 42
      hely = index
print(legnagyobb, hely+1)


legkisebb = szamok[0]
hely = 0
for i in range(len(szamok)):
   if szamok[i] < legkisebb:
      legkisebb = szamok[i]
      hely = i
print(legkisebb, hely+1)      





  

      

 