import random
"""
# halokSulya = []
# for i in range(8):
#     halosSulya = random.randint(20,50)
#     halokSulya.append(halosSulya)
# print(halokSulya)   

haloksulya = [random.randint(20,50) for i in range(8)]
print(haloksulya)

print(f"A halászok {len(haloksulya)}x mérték a hálókat.")
print(f"A hálók összsúlya {sum(haloksulya)} kg.")
atlag = sum(haloksulya) / len(haloksulya)
print(f"A hálók átlagos súlya {round(atlag,2)} kg.")

while True:
   kivantHaloSulya = int(input("Hanyadik háló súlyára kíváncsi?"))
   if  1 <= kivantHaloSulya <= 8:
      break
   else:
      print("Nincs ilyen háló!")

print(f"A {kivantHaloSulya} kívánt háló súlya: {haloksulya[kivantHaloSulya-1]} kg.")

db = 0
for i in haloksulya:
   if i > 40:
     db += 1
print(f"{db} db háló súlya haladta meg a 40 kg-ot.")    

rosszHalo = False
for i in haloksulya:
   if i < 10:
      rosszHalo = True
      break

if rosszHalo:
   print("Volt olyan háló, amelyik 10 kg alatti volt.")
else:
   print("Nem olyan háló, amelyik 10 kg alatti volt.")

#[40, 23, 30, 45, 30, 28, 36, 27]
max = haloksulya[0] # 40
index  = 0
for i in range(len(haloksulya)): # 0-7 
    if haloksulya[i] > max:
       max = haloksulya[i]
       index  = i
print(f"A legtöbb halat {index+1}:00 kor fogták, melynek súlya {max} kg volt. ")
"""


"""
for i in range(8):
    halo = []
    n = random.randint(20,50) # 21
    for j in range(n): # 0-21
        halsulya = random.uniform(1,20)
        halsulya = round(halsulya,2)
        halo.append(halsulya)
    halok.append(halo)    

for i in halok:
    print(i)
"""
halok = []
for i in range(8):
    n = random.randint(20,50)
    halo = [round(random.uniform(1,20),2) for i in range(n)]
    halok.append(halo)
#print(halok)   

for i in halok:
    print(i)

print("1. feladat")
print(f"A halászok {len(halok)}x mértek.")


haloksulya = 0
for i in halok:
    haloksulya += sum(i)

print("2. feladat")
print(f"A hálók összsúlya reggel 8:00-ra {haloksulya} kg.")

print("3. feladat")
print("Az egyes hálók összsúlya: ", end="")

egyeshalokSulya = []
for i in halok:
    halosulya = round(sum(i))
    print(halosulya, end=" ")
    egyeshalokSulya.append(halosulya)
print()

print("4. feladat")
print("A hálók átlagos súlya:", round( haloksulya / len(halok), 2), "kg.")

print("5. feladat")
db =0
for i in halok:
    if sum(i) > 300:
        db += 1
print(f"{db} db háló súlya haladta meg a 300 kg-ot.")        

print("6. feladat")
konnyuHalo = False
for i in halok:
    if sum(i) < 250:
        konnyuHalo = True
        break
if konnyuHalo:
    print("Volt olyan háló, amelyik 250 kg alatti volt.")   
else:
    print("Nem volt olyan háló, amelyik 250 kg alatti volt.")     

print("7. feladat")    
print(egyeshalokSulya)

legsulyosabb = egyeshalokSulya[0]
helye = 0
for index, ertek in enumerate(egyeshalokSulya):
    if ertek > legsulyosabb:
        legsulyosabb = ertek
        helye = index
print(f"A legsúlyosabb hálót {helye+1}:00-kor mérlegelték, melynek súlya {legsulyosabb} kg volt.")

print("8. feladat")  
nagyhalak = [] 
for i in halok:
    nagyhalak.append(max(i))
print(nagyhalak)     
    
legesleg = max(nagyhalak) 
legesleghelye = nagyhalak.index(legesleg)
print(f"A legsúlyosabb hal {legesleg} kg volt és {legesleghelye+1}:00 kor fogták.")


    
    





